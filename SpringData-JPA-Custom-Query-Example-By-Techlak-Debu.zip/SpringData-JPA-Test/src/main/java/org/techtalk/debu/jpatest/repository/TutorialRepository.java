package org.techtalk.debu.jpatest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.techtalk.debu.jpatest.entity.Tutorial;

@Repository
public interface TutorialRepository extends JpaRepository<Tutorial, Long> {

	@Query("SELECT t FROM Tutorial t")
	List<Tutorial> findAll();

	@Query("SELECT t FROM Tutorial t WHERE t.published=?1")
	List<Tutorial> findByPublished(boolean isPublished);

	@Query("SELECT t FROM Tutorial t WHERE t.title LIKE %?1%")
	List<Tutorial> findByTitleLike(String title);

/*	@Query("SELECT t FROM Tutorial t WHERE LOWER(t.title) LIKE LOWER(CONCAT('%', ?1,'%'))")
	List<Tutorial> findByTitleLikeCaseInsensitive(String title);*/
	

}
