package org.techtalk.debu.jpatest.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.techtalk.debu.jpatest.entity.Tutorial;
import org.techtalk.debu.jpatest.repository.TutorialRepository;

@Service
public class TutorialServiceImpl {

	@Autowired
	private TutorialRepository tutorialRepository;
	
	@Transactional
	public Tutorial save(Tutorial tutorialObj) {
		return tutorialRepository.save(tutorialObj);
	}
	
	@Transactional
	public List<Tutorial> findAll() {
		return tutorialRepository.findAll();
	}
	
	
	@Transactional
	public List<Tutorial> findByPublished(String isPublished) {
		boolean status = false;
		if(isPublished.equalsIgnoreCase("true"))
			status = true;
		return tutorialRepository.findByPublished(status);
	}
	
	
	@Transactional
	public List<Tutorial> findByTitleLike(String title) {
		return tutorialRepository.findByTitleLike(title);
	}
	
	
}
